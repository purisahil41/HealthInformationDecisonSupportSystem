import d3 from 'd3';
import _ from 'lodash';
import $ from 'jquery';
import S from './lib/d3-plugins-sankey/sankey';
import dateFormat from './lib/dateformat';
import sankeyAggResponseProvider from './lib/agg_response';
import uiModules from 'ui/modules';
import FilterBarQueryFilterProvider from 'ui/filter_bar/query_filter';


const module = uiModules.get('kibana/kbn_sankey_vis', ['kibana']);

module.controller('KbnSankeyVisController', function($scope, $element, Private) {

    const sankeyAggResponse = Private(sankeyAggResponseProvider);
    var filterManager = Private(require('ui/filter_manager'));
    var formatNumber = d3.format(',.0f');
    var format = function(d) {
        return formatNumber(d);
    };

    var svgRoot = $element[0];
    var color = d3.scale.category10();
    var margin = 20;
    var width;
    var height;
    var div;
    var svg;

    var _updateDimensions = function() {
        var delta = 18;
        var w = $element.parent().width();
        var h = $element.parent().height();
        if (w) {
            if (w > delta) {
                w -= delta;
            }
            width = w;
        }
        if (h) {
            if (h > delta) {
                h -= delta;
            }
            height = h;
        }
    };


    var _buildVis = function(data) {
        var energy = data.slices;
        var nodeStruct = data.structNodes;
        div = d3.select(svgRoot);
        if (!energy.nodes.length) return;
        var strVal = "0 0 " + (width + 20) + " " + (height + 20) + "";
        svg = d3.select(svgRoot).append('svg')
            
            .attr("viewBox", strVal)
            //class to make it responsive
            .attr("preserveAspectRatio", "none")
            .attr('width', '100%')
             .attr('height', '100%')
            .append('g')
            .attr('transform', 'translate(0, 0)');



        var sankey = d3.sankey()
            .nodeWidth(15)
            .nodePadding(10)
            .size([width, height]);

        var path = sankey.link();

        sankey
            .nodes(energy.nodes)
            .links(energy.links)
            .layout(32);

        var link = svg.append('g').selectAll('.link')
            .data(energy.links)
            .enter().append('path')
            .attr('class', 'link')
            .attr('d', path)
            .style('stroke-width', function(d) {
                return Math.max(1, d.dy);
            })
            .sort(function(a, b) {
                return b.dy - a.dy;
            })
            .on('click', function() {
                pathClicked(this);
            });

        link.append('title')
            .text(function(d) {
                return d.source.name + ' → ' + d.target.name + '\n' + format(d.value);
            });

        var node = svg.append('g').selectAll('.node')
            .data(energy.nodes)
            .enter().append('g')
            .attr('class', 'node')
            .attr('transform', function(d) {
                 if(d.x == NaN || d.y == NaN)
            {
               //alert('Nan case');
            }
            else
                return 'translate(' + d.x + ',' + d.y + ')';
            })
            .call(d3.behavior.drag()
                .origin(function(d) {
                    return d;
                })
                .on('dragstart', function() {

                })
                .on('drag', dragmove)).on('click', function() {
                if (d3.event.defaultPrevented) return; // dragged
                nodeClicked(this);
            });


        node.append('rect')
            .attr('height', function(d) {
                return d.dy;
            })
            .attr('width', sankey.nodeWidth())
            .style('fill', function(d) {
                return d.color = color(d.name);
            })
            .style('stroke', function(d) {
                return d3.rgb(d.color).darker(2);
            })
            .append('title')
            .text(function(d) {
                return d.name + '\n' + format(d.value);
            })



        node.append('text')
            .attr('x', -6)
            .attr('y', function(d) {
                return d.dy / 2;
            })
            .attr('dy', '.1em')
            .attr('text-anchor', 'end').
            attr('style','font-size:1em;')
            .attr('transform', null)
            .text(function(d) {
                return d.name;
            })
            .filter(function(d) {
                return d.x < width / 2;
            })
            .attr('x', 6 + sankey.nodeWidth())
            .attr('text-anchor', 'start').
            attr('style','font-size:1em;');


        function dragmove(d) {
            this.parentNode.appendChild(this);
            d3.select(this).attr('transform', 'translate(' + (d.x = Math.max(0, Math.min(width - d.dx, d3.event.x))) + ',' + (d.y = Math.max(0, Math.min(height - d.dy, d3.event.y))) + ')');
            sankey.relayout();
            link.attr('d', path);
        }

        function pathClicked(path) {
            var structure = nodeStruct;
            var sourceVal = path.__data__.source.name;
            var filterKeyWord = $scope.vis.aggs.bySchemaName['segment'][0].params.field;
             if (filterKeyWord.format.constructor.name == "DateTime") {
                var dtObj = new Date(structure[sourceVal]).toGMTString();
                //filteredVal = dtObj;//.getTime();
                sourceVal = dateFormat(dtObj, 'dd/mm/yy', true);
            }
            filterManager.add(
                // The field to filter for, we can get it from the config
                $scope.vis.aggs.bySchemaName['segment'][0].params.field,
                // The value to filter for, we will read out the bucket key from the tag
                sourceVal,
                // Whether the filter is negated. If you want to create a negated filter pass '-' here
                null,
                // The index pattern for the filter
                $scope.vis.indexPattern.title
            );
            var targetVal = path.__data__.target.name;
            filterKeyWord = $scope.vis.aggs.bySchemaName['segment'][1].params.field;
            if (filterKeyWord.format.constructor.name == "DateTime") {
                var dtObj = new Date(structure[targetVal]).toGMTString();
                //filteredVal = dtObj;//.getTime();
                targetVal = dateFormat(dtObj, 'dd/mm/yy', true);
            }
            else if(filterKeyWord.format.constructor.name == "Class" && filterKeyWord.format.type.title == "Number")
            {
                targetVal = targetVal.replace(",","");
            }
            filterManager.add(
                // The field to filter for, we can get it from the config
                $scope.vis.aggs.bySchemaName['segment'][1].params.field,
                // The value to filter for, we will read out the bucket key from the tag
                targetVal,
                // Whether the filter is negated. If you want to create a negated filter pass '-' here
                null,
                // The index pattern for the filter
                $scope.vis.indexPattern.title
            );
        }

        function nodeClicked(rect) {
            const queryFilter = Private(FilterBarQueryFilterProvider);
            queryFilter.getFilters(); // returns array of **pinned** filters
            var isTimeFilter = true;
            var filteredVal = rect.__data__.name;
            var filterKeyWord = "";
            var structure = nodeStruct;
            var nodeData = rect.__data__;
            if (nodeData.sourceLinks.length > 0) {
                filterKeyWord = $scope.vis.aggs.bySchemaName['segment'][0].params.field;
            } else {
                filterKeyWord = $scope.vis.aggs.bySchemaName['segment'][1].params.field;
            }

            if (filterKeyWord.format.constructor.name == "DateTime") {
                var dtObj = new Date(structure[filteredVal]).toGMTString();
                //filteredVal = dtObj;//.getTime();
                filteredVal = dateFormat(dtObj, 'dd/mm/yy', true);
            }

            // Add a new filter via the filter manager
            filterManager.add(
                // The field to filter for, we can get it from the config
                filterKeyWord,
                // The value to filter for, we will read out the bucket key from the tag
                filteredVal,
                // Whether the filter is negated. If you want to create a negated filter pass '-' here
                null,
                // The index pattern for the filter
                $scope.vis.indexPattern.title
            );
        }
    }


    var _render = function(data) {
        d3.select(svgRoot).selectAll('svg').remove();
        _buildVis(data);
    };

    $scope.$watch('esResponse', function(resp) {
        if (resp) {
            var chartData = sankeyAggResponse($scope.vis, resp);
            _updateDimensions();
            _render(chartData);
        }
    });
});