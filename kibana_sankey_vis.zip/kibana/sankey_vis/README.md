# Kibana Sankey Diagram Plugin

This is a sankey diagram visType plugin for Kibana 4.3+, 5.x.

This plugin was developped from <https://github.com/elastic/kibana/pull/4832>.

![](https://cloud.githubusercontent.com/assets/1219655/21418571/29e596d8-c85d-11e6-8060-11c0add8bf5b.png)

# Install

```
cd KIBANA_FOLDER_PATH/plugins/
git clone https://github.com/chenryn/kbn_sankey_vis.git
```

# Uninstall

```
bin/kibana plugin  --remove kbn_sankey_vis
```
